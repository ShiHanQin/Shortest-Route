/*TezlaSQH.java
 * November 8th, 2017
 * Shi Han Qin
 * Purpose: Finds the most efficient path through a map, displays the gas left, and outputs a path in another text file
 */

/*General Remarks:
 * Coordinates for position are relative to top left square being (0,0)
 * This program uses 2 methods aside from main, one for moving the car and the other for checking if backtracking should be allowed
 * It is assumed that S is always located at (1,0) and D is always located at (N-1,N)
 */

import java.io.*; //Will be used for reading from and writing to files
import java.util.Scanner; //Will be used to scan data into program

public class TezlaSQH{
  //Main method that will load map and call other methods
  public static void main(String[] args) throws Exception { //must throw an Exception, for errors that can occur
    try{ //To prevent errors
      Scanner input = new Scanner(System.in);//Scanner for user input
      File newFile = new java.io.File("ROUTE.txt"); //Text file the new map will be printed
      
      //Output a welcome message:
      System.out.println("                                        Welcome to Electric Car Confusion!"); 
      System.out.println("");
      
      //Get inputs from the user:
      System.out.println("Please enter the name (with correct casing) of the text file you want to use without the .txt extension"); 
      String fileName=input.next();
      File file = new java.io.File(fileName+".txt"); // Text file the map is in
      Scanner inFile = new Scanner(file); // Create a Scanner for the file
      
      //Read Data from the text file:
      int rows=inFile.nextInt();//Finds number of rows
      String filter=inFile.nextLine();//Filters out the space after the numbers
      int columns = inFile.nextInt();//Find number of columns
      filter=inFile.nextLine();//Filters out the space after the numbers
      int gas=inFile.nextInt() +1 ;//Finds the amount of gas provided
      filter=inFile.nextLine();//Filters out the space after the numbers
      
      String[][] cityMap= new String [rows][columns];//Declares the array that will store the map
      String[][] leastGasMap=new String [rows][columns];//Make a copy of the map that will store the moste efficient path
      
      //Assign the array the map values
      for (int i=0; i<rows; i++){
        String value=inFile.nextLine();
        for (int j=1; j<=columns; j++){
          cityMap[i][j-1]=value.substring(j-1,j);
        }
      }
      //Create the clone of the city map in another array
      for (int i = 0; i < rows; i++) {
        for (int j = 0; j < columns; j++) {
          leastGasMap[i][j] = cityMap[i][j];
        }
      }
      
      //Initialize variables to pass through following method
      int posX=1, posY=0, leastGas=0, canRepeat=0; //Start is always at (1,0) 
      //Call the method to move the car
      int finalGas= carTrail(rows, columns, posX, posY, cityMap, gas, leastGasMap, leastGas, canRepeat);//Call method to see how the car is to move
      
      //Display the outputs and results
      System.out.println(" ");
      System.out.println("The most gas left: "); //Display the gas left
      System.out.println(finalGas);
      
      //Display a goodbye message:
      System.out.println("");
      System.out.println("The map with the best path has been outputted in ROUTE.TXT. * marks the path and G marks the gas stations the car has used.");
      System.out.println("                                           Thank you for using this program!");
      
      inFile.close(); //Close the Scanner
      
      //This prints the map with a starred path to the text file
      PrintWriter outFile = new PrintWriter(newFile);
      for (int i=0; i<rows; i++){
        for (int j=0; j<columns; j++){
          outFile.print(leastGasMap[i][j]);
        }
        outFile.println(" "); 
      }
      outFile.close();// Close the PrintWriter
    }catch (FileNotFoundException e) {}; //Catches potential errors
  }//End of main
  
  /***************************************************************************************************************************************************************************************/  
  //Method for moving the car  
  public static int carTrail(int rows, int columns, int posX, int posY, String[][] cityMap, int gas, String[][] leastGasMap, int leastGas, int canRepeat) {
    gas--; //Gas is subtracted by one for every step
    
    if (gas<0){ //No possible paths if gas is less than 0
      return -1;
    }
    
    if (cityMap[posX][posY].equals("D")) { //Base case of if "D" is reached
      if (gas > leastGas) {//Compare the gas left from multiple paths to find most efficient
        leastGas = gas; //Store the new most efficient gas amount
        for (int i = 0; i < rows; i++) {
          for (int j = 0; j < columns; j++) {
            leastGasMap[i][j] = cityMap[i][j]; //Loads the map with a starred path as the most efficient
          }
        }
      }
      return leastGas;//Returns the gas left
    } 
    
    //Temporarily mark the map with other symbols so recursive calls will know where not to go
    if (cityMap[posX][posY].equals(" ")){
      cityMap[posX][posY] = "*";//Tracks where the car has already been so when the following statements check for spaces, it won't go back
    }else if (cityMap[posX][posY].equals("C")){
      cityMap[posX][posY] = "G"; //Marks the station as something else so that the car can't go back again and again
      canRepeat += 2; //Going a "C" and then back will take up 2 gasses, and this value will be used later on to see if going to a charging station out of the way will give the car more gas 
      gas += 5; //Gas goes up by 5 when it passes through a charing station
    } else if (cityMap[posX][posY].equals("*")) { //This condition is used after the car goes onto a charging station It tests to see if going backwards will be worthwhile
      cityMap[posX][posY] = "R";//Reprsents the second time on a space        
      if (canRepeat>0){ //See if "repeating" a square is affordable  
        canRepeat--; //Decrement so car doesn't keep going back and forth
      }
    } else if (cityMap[posX][posY].equals("G")) { //If the car is on a charging station 
      cityMap[posX][posY] = "P"; //Prevents the car from moving to a charging station twice
      if (canRepeat>0)
        canRepeat--;
    }
    
    ////////////////////////////////////////////////CHECKING THE FOUR DIRECTIONS//////////////////////////////////////////////////////
    //Check if car can move down
    if ((posX+1 < columns) && canMoveOn(posX + 1, posY, canRepeat, cityMap)) {
      leastGas = carTrail(rows, columns, posX+1, posY, cityMap, gas, leastGasMap,  leastGas, canRepeat);   
    } 
    //Check if car can move right
    if ((posY+1 < rows) && canMoveOn(posX , posY + 1, canRepeat, cityMap)) {
      leastGas =  carTrail(rows, columns, posX, posY+1, cityMap, gas, leastGasMap,  leastGas, canRepeat);   
    } 
    //Check if car can move up
    if ((posX > 0) && canMoveOn(posX-1, posY , canRepeat, cityMap)) {
      leastGas =  carTrail(rows, columns, posX-1, posY, cityMap, gas, leastGasMap,  leastGas, canRepeat);   
    } 
    //Check if car can move left
    if ((posY > 0) && canMoveOn(posX , posY - 1, canRepeat, cityMap)) {
      leastGas =  carTrail(rows, columns, posX, posY-1, cityMap, gas, leastGasMap,  leastGas, canRepeat);   
    } 
    
    //Reset everything to orignal so program will work for following run throughs
    if (cityMap[posX][posY].equals("*")){
      cityMap[posX][posY] = " ";//Tracks where the car has already been so when the following statements check for spaces, it won't go back
    }else if (cityMap[posX][posY].equals("G")){
      cityMap[posX][posY] = "C";
    }else if (cityMap[posX][posY].equals("R")){
      cityMap[posX][posY] = "*";
    }else if (cityMap[posX][posY].equals("P")){
      cityMap[posX][posY] = "G";
    }
    
    return leastGas;//Final value of most gas left is returned
  }//End of carTrail
  
  /***************************************************************************************************************************************************************************************************************/  
  //Method to test if car is allowed to move in spot it has previously been in before
  //This method will return a true/false value that will be used in the carTrail method to see if it is allowed to move in a cetain direction 
  public static boolean canMoveOn(int posX, int posY, int canRepeat, String[][] cityMap) {
    //First condition will allow the car to move anywhere but walls, backwards is allowed as long as canRepeat is greater the 0, signifiying its affordable
    if (cityMap[posX][posY].equals(" ") || cityMap[posX][posY].equals("D") || cityMap[posX][posY].equals("C") || ((cityMap[posX ][posY].equals("*")||cityMap[posX][posY].equals("G")) && canRepeat >0))
      return true;
    else{ //Prohibits from moving elsewhere
      return false;
    }
  }//End of canMoveOn
}//End of class